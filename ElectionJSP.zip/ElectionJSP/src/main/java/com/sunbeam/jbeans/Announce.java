package com.sunbeam.jbeans;

public class Announce {
	
	private String ann;

	public String getAnn() {
		return ann;
	}

	public void setAnn(String ann) {
		this.ann = ann;
	}

	@Override
	public String toString() {
		return "Announce [ann=" + ann + "]";
	}
	
	
}
